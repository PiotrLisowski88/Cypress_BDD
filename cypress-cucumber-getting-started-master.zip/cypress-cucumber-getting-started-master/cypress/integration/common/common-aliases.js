/** 
 * Aliases for hideous selectors can be placed here.
 */

export {alias}

const alias = {
  mainHeadline: 'h1',
  navigationLinks: '.home-list a'
}